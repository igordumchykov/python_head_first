from setuptools import setup

setup(
    name='functions',
    version='1.0',
    description='My first module',
    author='Igor Dumchykov',
    author_email='igor.dumchykov@gmail.com',
    url='headfirstlabs.com',
    py_modules=['functions']
)